//
//  CollectionImageViewController.swift
//  ClientServerAssignment
//
//  Created by TTN on 18/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

extension UIImageView {
    func downloadedFrom(url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        contentMode = mode
        print("URL is here \(url)")
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { [weak self] in
                self?.image = image
            }
        }.resume()
    }
    
    func downloaded(from link: String, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloadedFrom(url: url, contentMode: mode)
    }
}


class CollectionImageViewController: UIViewController {
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var idLabel: UILabel!
    
    @IBOutlet weak var filenameLabel: UILabel!
    
    @IBOutlet weak var widthLabel: UILabel!
    
    @IBOutlet weak var heightLabel: UILabel!
    
    @IBOutlet weak var formatLabel: UILabel!
    
    @IBOutlet weak var authorLabel: UILabel!
    
    open var gotDetails: details?
    var objCollectionViewController = CollectionViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(objCollectionViewController.getDetails.count)
        idLabel.text = "\((gotDetails?.id) ?? 0)"
        authorLabel.text = gotDetails?.author
        widthLabel.text = "\((gotDetails?.width) ?? 0)"
        heightLabel.text = "\((gotDetails?.height) ?? 0)"
        filenameLabel.text = gotDetails?.filename
        formatLabel.text = gotDetails?.format
       
        var id : String = "\((gotDetails?.id) ?? 0)"
        let urlString = "https://picsum.photos/200/300?image=" + id
        let url = URL(string: urlString)!
        
        imageView.downloadedFrom(url: url)
    }
    
}
