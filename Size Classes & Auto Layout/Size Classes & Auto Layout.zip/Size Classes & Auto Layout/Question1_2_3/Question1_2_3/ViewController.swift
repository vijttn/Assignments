//
//  ViewController.swift
//  Question1_2_3
//
//  Created by TTN on 15/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
@IBOutlet weak var circularImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        circularImage.layer.cornerRadius = circularImage.bounds.width / 2
    }

    
    
    
}

