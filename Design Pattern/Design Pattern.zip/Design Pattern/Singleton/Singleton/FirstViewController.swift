//
//  FirstViewController.swift
//  Singleton
//
//  Created by TTN on 24/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var myTableView: UITableView!
    
    
    
    var objArray1VC = person.shared.objOfPerson
    

    
       override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view.
           myTableView.register(CustomTableViewCell.nib(), forCellReuseIdentifier: CustomTableViewCell.identifier)
           myTableView.delegate = self
           myTableView.dataSource = self
       }
    
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return objArray1VC.count
         }
         
         func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

           
           let cell = myTableView.dequeueReusableCell(withIdentifier: CustomTableViewCell.identifier, for: indexPath) as! CustomTableViewCell
           
           cell.configureMyFunction1(element: objArray1VC[indexPath.row])
           return cell
         }

    
}
