//
//  ViewController.swift
//  Singleton
//
//  Created by TTN on 24/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

struct  personModel {
    
    var name: String?
    var email: String?
    var address: String?
    var zipcode: String?
}

var objArray = [ personModel(name: "Alex", email: "A@gmail.com", address: "America", zipcode: "101"),
    personModel(name: "Bob", email: "B@gmail.com", address: "Bulgaria", zipcode: "102"),
    personModel(name: "Cathy", email: "C@gmail.com", address: "China", zipcode: "103"),
    personModel(name: "Doug", email: "D@gmail.com", address: "Denmark", zipcode: "104"),
    personModel(name: "Eon", email: "E@gmail.com", address: "England", zipcode: "105"),
    personModel(name: "Farhan", email: "F@gmail.com", address: "France", zipcode: "106"),
    personModel(name: "Giddy", email: "G@gmail.com", address: "Gotham", zipcode: "107"),
    personModel(name: "Henry", email: "H@gmail.com", address: "Hungry", zipcode: "108"),
    personModel(name: "Isha", email: "I@gmail.com", address: "Iran", zipcode: "109"),
    personModel(name: "Jacob", email: "J@gmail.com", address: "Japan", zipcode: "110")
   ]

class  person {
    static let shared = person()

    private init(){}
    
    var objOfPerson : [personModel] = objArray
}



class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
   
    
    @IBAction func pressedToGoToFirstVC(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(identifier: "First") as! FirstViewController
              vc.navigationItem.largeTitleDisplayMode = .never
              navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    @IBAction func pressedToGoToSecondVC(_ sender: Any) {
      
        let vc = storyboard?.instantiateViewController(identifier: "Second") as! SecondViewController
        vc.navigationItem.largeTitleDisplayMode = .never
        navigationController?.pushViewController(vc, animated: true)
      
    }
    
    @IBAction func pressedToGoToThirdVC(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(identifier: "Third") as! ThirdViewController
        vc.navigationItem.largeTitleDisplayMode = .never
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
   
    
//    FirstViewController.valueTransferred(objArray)
}


