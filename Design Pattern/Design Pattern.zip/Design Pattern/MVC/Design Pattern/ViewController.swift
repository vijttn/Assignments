//
//  ViewController.swift
//  Design Pattern
//
//  Created by TTN on 22/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

public struct person {
     public var name: String
     public var email: String
     public var address: String
     public var zipCode: String
   }

var objArray = [person(name: "Alex", email: "Alex@gmail.com", address: "America",                 zipCode: "101"),
person(name: "Ben", email: "Ben@gmial.com", address: "England", zipCode: "102"),
person(name: "Ashley", email: "Ashley@gmial.com", address: "Africa", zipCode: "103"),
person(name: "Tom", email: "Tom@gmial.com", address: "Scranton", zipCode: "104"),
person(name: "Mark", email: "Mark@gmial.com", address: "Scotland", zipCode: "105"),
person(name: "Hawk", email: "Hawk@gmial.com", address: "Russia", zipCode: "106"),
person(name: "Iron", email: "Iron@gmial.com", address: "England", zipCode: "107"),
person(name: "Man", email: "Man@gmial.com", address: "Australia", zipCode: "108"),
person(name: "Captain", email: "Captain@gmial.com", address: "India", zipCode: "109"),
person(name: "Lady", email: "Lady@gmial.com", address: "Dubai", zipCode: "110"),
      ]

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  
    @IBOutlet weak var myTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        myTableView.register(CustomTableViewCell.nib(), forCellReuseIdentifier: CustomTableViewCell.identifier)
        myTableView.delegate = self
        myTableView.dataSource = self
    }
 
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return objArray.count
      }
      
      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        
        let cell = myTableView.dequeueReusableCell(withIdentifier: CustomTableViewCell.identifier, for: indexPath) as! CustomTableViewCell
        
        cell.configureMyFunction(element: objArray[indexPath.row])
        return cell
      }
    
    
    
}

