//
//  ContentView.swift
//  BootcampSwiftUI
//
//  Created by TTN on 06/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//


import SwiftUI

struct ContentView : View {
    var body: some View {
       return NavigationView {
            List {
                Section(header: Text("Basic Controls")) {
            
                    NavigationLink(destination: ImageSwiftUIView()) {
                        Text("Image")
                    }
                    NavigationLink(destination: TextSwiftUIView()) {
                        Text("Text")
                    }
                    NavigationLink(destination: VerticalStackSwiftUIView()) {
                        Text("Vertical Stack View")
                    }
                    NavigationLink(destination: HorizontalStackSwiftUIView()) {
                        Text("Horizontal Stack View")
                    }
                    NavigationLink(destination: ButtonSwiftUIView()) {
                        Text("Button")
                    }
                    NavigationLink(destination: PickerSwiftUIView()) {
                        Text("Picker")
                    }
                }
            Section(header: Text("Miscellaneous")) {
                        NavigationLink(destination: MultipleDevicePreview()) {
                            Text("Multiple Device Preview")
                        }
                    }
                    
                }.navigationBarTitle(Text("Welcome to SwiftUI"))
            }
        }
    }


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
