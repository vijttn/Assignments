//
//  ButtonSwiftUIView.swift
//  BootcampSwiftUI
//
//  Created by TTN on 06/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct ButtonSwiftUIView : View {
    var body: some View {
        
        Button(action: {
            
        }, label: {
            Text("Sample Button")
                .foregroundColor(.white)
        })
            .padding(.all, 20.0)
            .frame(width: 300.0)
            .background(Color.blue)
            .cornerRadius(5)
    }
    
}


struct ButtonSwiftUIView_Previews : PreviewProvider {
    static var previews: some View {
        ButtonSwiftUIView()
    }
}

