//
//  HorizontalStackSwiftUIView.swift
//  BootcampSwiftUI
//
//  Created by TTN on 06/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct HorizontalStackSwiftUIView : View {
    var body: some View {
        HStack(alignment: .top, spacing: 20.0) {
            Text("First Horizontal Stack Text")
                .padding(.all, 10.0)
                .lineLimit(nil)
            Text("Second Horizontal Stack Text")
                .padding(.all, 10.0)
                .lineLimit(nil)
        }
        .background(Color.green)
        .padding(.all, 10.0)
    }
}


struct HorizontalStackSwiftUIView_Previews : PreviewProvider {
    static var previews: some View {
        HorizontalStackSwiftUIView()
    }
}

