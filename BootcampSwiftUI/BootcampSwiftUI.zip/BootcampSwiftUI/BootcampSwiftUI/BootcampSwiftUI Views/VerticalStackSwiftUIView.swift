//
//  VerticalStackSwiftUIView.swift
//  BootcampSwiftUI
//
//  Created by TTN on 06/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct VerticalStackSwiftUIView : View {
    var body: some View {
        VStack {
            Text("First Vertical Stack Text")
                .padding(.all, 10.0)
                .lineLimit(nil)
            Text("Second Vertical Stack Text")
                .padding(.all, 10.0)
                .lineLimit(nil)
            Text("Third Vertical Stack Text")
                .padding(.all, 10.0)
                .lineLimit(nil)
            Text("Fourth Vertical Stack Text")
                .padding(.all, 10.0)
                .lineLimit(nil)
            Text("Fifth Vertical Stack Text")
                .padding(.all, 10.0)
                .lineLimit(nil)
            Text("Sixth Vertical Stack Text")
                .padding(.all, 10.0)
                .lineLimit(nil)
        }.background(Color.blue)
    }
}


struct VerticalStackSwiftUIView_Previews : PreviewProvider {
    static var previews: some View {
        VerticalStackSwiftUIView()
    }
}


