//
//  ImageSwiftUIView.swift
//  BootcampSwiftUI
//
//  Created by TTN on 06/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct ImageSwiftUIView : View {
    var body: some View {
        Image("dog3")
        .resizable()
        .aspectRatio(contentMode: .fill)
        .frame(width: 600.0, height: 300.0)
    }
}


struct ImageSwiftUIView_Previews : PreviewProvider {
    static var previews: some View {
        ImageSwiftUIView()
    }
}

