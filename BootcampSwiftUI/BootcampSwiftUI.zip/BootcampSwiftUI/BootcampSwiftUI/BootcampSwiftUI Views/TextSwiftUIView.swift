//
//  TextSwiftUIView.swift
//  BootcampSwiftUI
//
//  Created by TTN on 06/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct TextSwiftUIView : View {
    var body: some View {
        Text("This is Sample text with multiple lines. This is Sample text with multiple lines.")
            .fontWeight(.bold)
            .foregroundColor(.orange)
            .multilineTextAlignment(.center)
            .padding(.all, 10.0)
            .lineLimit(nil)
    }
}


struct TextSwiftUIView_Previews : PreviewProvider {
    static var previews: some View {
        TextSwiftUIView()
    }
}

