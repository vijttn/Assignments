//
//  MultipleDevicePreview.swift
//  BootcampSwiftUI
//
//  Created by TTN on 06/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct MultipleDevicePreview: View {
    var body: some View {
        Text("Welcome to multi device preview")
    }
}

struct MultipleDevicePreview_Previews: PreviewProvider {
    static var previews: some View {

        
        Group {
            MultipleDevicePreview()
            .previewDevice(PreviewDevice.init(rawValue: "iPhone 8"))
            .previewDisplayName("iPhone 8 4.7‑inch")
            
            MultipleDevicePreview()
            .previewDevice(PreviewDevice.init(rawValue: "iPhone 8 Plus"))
            .previewDisplayName("iPhone 8 Plus 5.5‑inch")
            
            MultipleDevicePreview()
            .previewDevice(PreviewDevice.init(rawValue: "iPhone 11 Pro"))
            .previewDisplayName("iPhone 11 Pro 5.8‑inch")
            
            MultipleDevicePreview()
            .previewDevice(PreviewDevice.init(rawValue: "iPhone 11 Pro Max"))
            .previewDisplayName("iPhone 11 Pro Max 6.5‑inch")
            
            MultipleDevicePreview()
            .previewDevice(PreviewDevice.init(rawValue: "iPhone 11"))
            .previewDisplayName("iPhone 11 6.1‑inch")
            
            
        }
    }
}
