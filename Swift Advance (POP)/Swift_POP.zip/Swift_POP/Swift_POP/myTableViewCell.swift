//
//  myTableViewCell.swift
//  Swift_POP
//
//  Created by TTN on 31/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class myTableViewCell: UITableViewCell {

    
    static  func nib() -> UINib{
        return UINib(nibName: "", bundle: <#T##Bundle?#>)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
