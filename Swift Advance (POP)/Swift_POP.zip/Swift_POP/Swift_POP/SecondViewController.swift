//
//  SecondViewController.swift
//  Swift_POP
//
//  Created by TTN on 01/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

struct General {
    var name: String
    var id: String
    var email: String
    var phoneNumber: String
    
    init(name: String, id: String, email: String, phoneNumber: String) {
        self.name = name
        self.id = id
        self.email = email
        self.phoneNumber = phoneNumber
    }
}

class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var userName: String = ""
    var email: String = ""
    var phoneNumber: String = ""
    var id: String = ""
    var imageOfUser: String = ""
    
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var contactLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var myTableView: UITableView!
    
    
     var model: Model = Model()
        var employeeArray: [Employee] {
            return model.employees
        }
        var clientArray: [User] {
            return model.users
        }
        var gens: [General] = []
        
        func convertDat() {
            for idx in 0..<employeeArray.count {
                gens.append(General(name: employeeArray[idx].name, id: employeeArray[idx].empId, email: employeeArray[idx].email, phoneNumber: employeeArray[idx].phoneNumber))
            }
            for idx in 0..<clientArray.count {
                gens.append(General(name: clientArray[idx].name, id: clientArray[idx].id, email: clientArray[idx].email, phoneNumber: clientArray[idx].phoneNumber))
            }
        }
        
        override func viewDidLoad() {
            super.viewDidLoad()
            convertDat()
            
            let nib = UINib(nibName: "customTableViewCell", bundle: nil)
            
            myTableView.register(nib, forCellReuseIdentifier: "customTableViewCell")
            
            myTableView.delegate = self
            myTableView.dataSource = self
            myTableView.reloadData()
            myTableView.layoutIfNeeded()
            idLabel.text = id
            nameLabel.text = userName
            emailLabel.text = email
            contactLabel.text = phoneNumber
            
            let image = UIImage(named: imageOfUser)
            userImage.image = image
    
    }
    
    override func viewDidLayoutSubviews() {
        myTableView.heightAnchor.constraint(equalToConstant:
        myTableView.contentSize.height).isActive = true
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return gens.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: customTableViewCell.identifier, for: indexPath) as! customTableViewCell
        cell.transferData(element: gens[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.showToast(message: "Hello \(gens[indexPath.row].name), how are you", font: .systemFont(ofSize: 12.0))
    }
            
    
}
