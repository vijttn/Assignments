//
//  Model.swift
//  Swift_POP
//
//  Created by TTN on 31/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import Foundation

extension Date {
    var currentDate: String {
        let joiningDate = Date()
        DateFormatter().dateFormat = "dd.MM.yyyy"
        let result = DateFormatter().string(from: joiningDate)
        return result
    }
}

struct  Employee {
    
    var name: String
    var email: String
    var address: String
    var empId: String
    var imgUser: String
    var joiningDate: Date
    var phoneNumber: String
}

struct User {
    
    var name: String
    var email: String
    var address: String
    var id: String
    var imgUser: String
    var phoneNumber: String
    
}

class Model {
    
    var employees: [Employee] = [
        Employee(name: "Alice", email: "alice@tothenew.com", address: "America", empId: "101", imgUser: "smiley", joiningDate: Date(), phoneNumber: "7776665554"),
        Employee(name: "Brandon", email: "brandon@tothenew.com", address: "Bulgaria", empId: "102", imgUser: "smiley", joiningDate: Date(), phoneNumber: "7776665553"),
        Employee(name: "Cathy", email: "cathy@tothenew.com", address: "China", empId: "103", imgUser: "smiley", joiningDate: Date(), phoneNumber: "7776665552"),
        Employee(name: "Denver", email: "denver@tothenew.com", address: "Denmark", empId: "104", imgUser: "smiley", joiningDate: Date(), phoneNumber: "7776665551")
    ]
    
    var users: [User] = [
    
        User(name: "Ashok", email: "ashok@tothenew.com", address: "Australia", id: "1", imgUser: "smiley", phoneNumber: "8887776665"),
        User(name: "Beth", email: "beth@tothenew.com", address: "Belgium", id: "2", imgUser: "smiley", phoneNumber: "8887776664"),
        User(name: "Casey", email: "casey@tothenew.com", address: "Canada", id: "3", imgUser: "smiley", phoneNumber: "8887776663"),
        User(name: "Djokovac", email: "djokovac@tothenew.com", address: "Dubai", id: "4", imgUser: "smiley", phoneNumber: "8887776662")
    
    ]
    
}
