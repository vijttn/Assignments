import UIKit

                                        /*////////////// Task 1 //////////////////// */

func siftBeans(fromGroceryist array: [String]) -> (beans: [String], other: [String]) {
    return (
        
        array.filter{ $0.hasSuffix("beans")},
        array.filter { !$0.hasSuffix("beans")}
    )
}

var result = siftBeans(fromGroceryist: ["green beans", "milk", "black beans", "pinto beans", "apples"])

result.beans == ["green beans", "black beans", "pinto beans"]

result.other == ["milk", "apples"]



                                 /*///////////// Task 2 ////////////////////////////// */
enum Cases {
    case multiply(Int, Int)
    case addition(Int, Int)
    case subtraction(Int, Int)
    case division(Int, Int)
    case squareroot(Float)
}

func equals (_ cases : Cases ) -> Int {
    switch cases {
    case let .multiply(a, b) :
        return(a*b)
    case let .addition(a, b) :
        return(a+b)
    case let .subtraction(a, b) :
        return(a-b)
    case let .division(a, b) :
        return (a/b)
    case let .squareroot(a) :
        return (Int (sqrt(a)))
}
}

    print(equals(Cases.multiply(2, 5)))
    print(equals(Cases.addition(2, 5)))
    print(equals(Cases.subtraction(7, 5)))
    print(equals(Cases.division(80, 10)))
    print(equals(Cases.squareroot(64)))


                                         /*///////////////////// Task 3 ///////////////////// */

struct calculator{
    var  a: Int
    var b: Int
    init(a: Int, b: Int) {
        self.a = a
        self.b = b
    }

    init(a: Int) {
        self.a = a
        self.b = 0
    }
    func addition(_ add: (Int, Int) -> Int) {
        print("\(a) + \(b) = \(add(a,b))")
    }
    func subtract(_ sub: (Int, Int) -> Int) {
        print("\(a) - \(b) = \(sub(a,b))")
    }
    func multiplication(_ mul: (Int, Int) -> Int){
        print("\(a) * \(b) = \(mul(a,b))")
    }
    func divison(_ div: (Int, Int) -> Int) {
        print("\(a) / \(b) = \(div(a,b))")
    }
    func squareroot(_ root: (Float) -> Float) {
        print("Square Root of \(a) = \(root(Float(a))) ")
    }

}

func add (a:Int, b:Int) -> Int{
    return a+b
}

func sub (a:Int, b:Int) -> Int{
    return a-b
}

func mul (a:Int, b:Int) -> Int{
    return a*b
}

func div (a:Int, b:Int) -> Int{
    return a/b
}

func root (a:Float) -> Float{
    return (sqrt(Float(a)))
}

calculator(a: 100, b: 50).addition(add)
calculator(a: 100, b: 50).subtract(sub)
calculator(a: 100, b: 50).multiplication(mul)
calculator(a: 100, b: 50).divison(div)
calculator(a: 25).squareroot(root)

                              /* ///////////////////////       Task4             /////////// */

struct myDataSource {
    var name: String
    var dance: Int
    var run: Int
    var Sing: Int
    var fight: Int
    var academic: Int
}

enum Task{
    case dance
    case run
    case sing
    case fight
    case academic

    func task() -> String {
        switch  self {
        case .dance:
            return "good dance"
        case .run:
            return "good run"
        case .sing:
            return "good sings"
        case .fight:
            return "good fights"
        case .academic:
            return "good academics"
        }
    }

    func filter(_ name: String, object: (String) -> Void ){
        object(name)
    }

}

class  TraineesActivity{

    lazy var myData: [myDataSource] = [.init(name: "Vijender", dance: 12, run: 73, Sing: 44, fight: 90, academic: 98),
                                       .init(name: "Rahul", dance: 23, run: 34, Sing: 46, fight: 56, academic: 67),
                                       .init(name: "Alez", dance: 44, run: 55, Sing: 22, fight: 78, academic: 23) ]

    var records1: [myDataSource] = []
    var records2: [Task] = []
    func performActivity(_ name: String, _ activity: Task){
        var tranieeobj: myDataSource? = nil
        activity.filter(name) { (name) in
            for data in myData where data.name == name {
                tranieeobj = data
            }
        }
        if tranieeobj != nil {
            print("\(tranieeobj?.name ?? "not") good \(activity) \(tranieeobj!.run)")
            recordActivity(trainee: tranieeobj!, Activity: activity)
        }
        else{
            print("No trainee found")
        }
    }

    func recordActivity(trainee traineeObj: myDataSource, Activity activity: Task) {
        records1.append(traineeObj)
        records2.append(activity)
    }

    func rerunActivity() {
        for i in records1 {
            for j in records2 {
                print("\(i.name) good " + "\(j)" + " \(i.run)" )
        }
    }
    }
//    init(_ closure: ([myDataSource]) -> Void) {
//
//        closure(myData)
//    }

}
var obj1 = TraineesActivity()
obj1.performActivity("Vijender", .run)
obj1.performActivity("Rahul", .run)
obj1.performActivity("Al", .academic)
obj1.rerunActivity()


