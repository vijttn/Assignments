//
//  ViewController.swift
//  Bootcamp(URLSession)
//
//  Created by TTN on 10/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func get(_ sender: Any) {
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        let url = URL(string: "https://jsonplaceholder.typicode.com/posts/")!
        
        let task = session.dataTask(with: url) { data, response, error in

               guard error == nil else {
                   print ("error: \(error!)")
                   return
               }
               
               guard let content = data else {
                   print("No data")
                   return
               }
               
               guard let json = (try? JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers)) as? [[String: Any]] else {
                   print("Not containing JSON")
                   return
               }
               
               print("The resultant dictionary is: \n \(json)")
           }
        task.resume()
        
    }
    
    @IBAction func post(_ sender: Any) {
        
            let config = URLSessionConfiguration.default
            let session = URLSession(configuration: config)

            guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else {
                return
            }
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "POST"

            let postDict : [String: Any] = ["postId": 000, "name": "Alex Bandwin", "email": "alexbaldwin@gmail.com", "id": 000, "body": "This is a sample text!!!!!!!!" ]

            guard let postData = try? JSONSerialization.data(withJSONObject: postDict, options: []) else {
                return
            }

            urlRequest.httpBody = postData

            let task = session.dataTask(with: urlRequest) { data, response, error in
                
                guard error == nil else {
                    print ("error: \(error!)")
                    return
                }
        
                guard let content = data else {
                    print("No data")
                    return
                }
                
                guard let json = (try? JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers)) as? [String: Any] else {
                    print("Not containing JSON")
                    return
                }
                print("The resultant dictionary is:  \n \(json)")
            }
            task.resume()
        
    }
}



