//
//  ThirdViewController.swift
//  Bootcamp(NavController)
//
//  Created by TTN on 05/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .systemTeal
        title = "How are you?"
        
    }
    
    
    
    @IBAction func goToNextScreen(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "fourth")
            as! FourthViewController
        vc.navigationItem.largeTitleDisplayMode = .never
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func popToRootVc(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


