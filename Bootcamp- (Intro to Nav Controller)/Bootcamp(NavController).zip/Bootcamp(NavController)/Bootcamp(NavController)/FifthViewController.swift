//
//  FifthViewController.swift
//  Bootcamp(NavController)
//
//  Created by TTN on 05/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class FifthViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGreen
    }
    
    @IBAction func dismiss(_ sender: Any) {
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
}
