import UIKit

                              /* Task 1 */

//In Swift, errors are represented by values of types that conform to the Error protocol. This empty protocol indicates that a type can be used for error handling.

enum myError: Error {
    case notFound
    case notTrue
    case anyError

}

func checkError(value: Bool?) throws -> String {
    if value == true {
        return "false"
    } else if value == false {
        throw myError.notTrue
    } else if value == nil {
        throw myError.notFound
    } else {
        throw myError.anyError
    }
}

do {
    try checkError(value: true)
    print("Yayyy")
}catch myError.notFound {
    print("Value not found")
}catch myError.notTrue {
    print("Value is false")
}catch myError.anyError{
    print("Error is unknown")
}

                                         /* Task 2 */

enum MagicWords: String {
  case abracadabra = "abracadabra"
  case alakazam = "alakazam"
  case hocusPocus = "hocus pocus"
  case prestoChango = "presto chango"
}

enum initialiseError: Error{
    case initialisationFailed
}

struct Spell {
  var magicWords: MagicWords = .abracadabra
    init?(words: String) throws {
      guard let temp = MagicWords(rawValue: words) else{
        throw initialiseError.initialisationFailed
      }
        self.magicWords = temp
    }
}

do {
    _ = try Spell(words: "absdsd")
} catch initialiseError.initialisationFailed{
    print("Object Not Able To Initialize")
}
 
                                /* Task 3 */

//try is used with a do-catch statement and allows for a more detailed approach to error handling.
//
//try? ignores our errors and will set them to nil if they happen to occur.
//
//try! force unwraps our code and guarantees that our function will never encounter an error. In the case that our function does throw an error our app will simply crash.
//
//
//enum MagicWords: String {
//  case abracadabra = "abracadabra"
//  case alakazam = "alakazam"
//  case hocusPocus = "hocus pocus"
//  case prestoChango = "presto chango"
//}
//
//enum initialiseError: Error{
//    case initialisationFailed
//}
//
//struct Spell {
//  var magicWords: MagicWords = .abracadabra
//    init?(words: String) throws {
//      guard let temp = MagicWords(rawValue: words) else{
//        throw initialiseError.initialisationFailed
//      }
//        self.magicWords = temp
//    }
//}
//
//let obj1 = try Spell(words: "alakazam") // works fine
//let obj2 = try? Spell(words: "") // returns nill
//let obj3 = try! Spell(words: "asb") //gives a fatal error


                                     /* Task 4*/

struct employee{
    var empID: Int
    var empName: String
    var empMail: String
    var empExperience: Float
    var isPresent: Bool
    var competency: String
    var attendancePresent: Int
}

var emp: [employee] = [employee(empID: 101, empName: "Nya", empMail: "Nya@tothenew.com", empExperience: 3, isPresent: true, competency: "Jvm",                              attendancePresent: 85),
                       employee(empID: 102, empName: "Abhi", empMail: "Abhi@tothenew.com", empExperience: 5, isPresent: true, competency: "iOS", attendancePresent: 90),
                       employee(empID: 103, empName: "Utkarsh", empMail: "Utkarsh@tothenew.com", empExperience: 2.5, isPresent: false, competency: "BigData", attendancePresent: 88),
                       employee(empID: 104, empName: "Raj", empMail: "Raj@tothenew.com", empExperience: 2, isPresent: true, competency: "android", attendancePresent: 78),
                       employee(empID: 105, empName: "Vij", empMail: "Vij@tothenew.com", empExperience: 4, isPresent: true, competency: "BigData", attendancePresent: 89),
                       employee(empID: 106, empName: "Rahul", empMail: "Rahul@tothenew.com", empExperience: 5, isPresent: true, competency: "iOS", attendancePresent: 96),
                       employee(empID: 107, empName: "Aryan", empMail: "Aryan@tothenew.com", empExperience: 3, isPresent: true, competency: "Qe", attendancePresent: 57),
                       employee(empID: 108, empName: "Kavya", empMail: "Kavya@tothenew.com", empExperience: 2, isPresent: true, competency: "iOS", attendancePresent: 85),
                       employee(empID: 109, empName: "Srishti", empMail: "Srishti@tothenew.com", empExperience: 1.5, isPresent: false, competency: "android", attendancePresent: 98),
                       employee(empID: 110, empName: "Harsh", empMail: "Harsh@tothenew.com", empExperience: 0.5, isPresent: true, competency: "Jvm", attendancePresent: 90)
            ]

enum empBonusError: Error {
    case isPresent (String)
    case inExperienced(String)
    case avgCompetency(String)
    case avgAttendance(String)
    
    var reason: String{
        switch self {
        case .isPresent(let name):
            return name + " is not present"
        case .inExperienced(let name):
            return name + " has not completed a year with us"
        case .avgCompetency(let name):
            return name + " is not from a hot competency"
        case .avgAttendance(let name):
            return name + "'s attendance is not upto the mark"
        }
    }

}

class BonusProgram{
    
    func allowedForBonus(empEmail: String) throws -> Void {
        
        var i: employee {
            var object: employee? = nil
            for obj in emp where empEmail == obj.empMail{
                object = obj
            }
            return object!
        }
        
            if i.isPresent == true {
                if i.empExperience > 1.0 {
                    if i.competency == "iOS" || i.competency == "android" || i.competency == "BigData" || i.competency == "AI" {
                        if i.attendancePresent > 80 {
                            print("\(i.empName) is eligible for bonus")
                        }else {
                            throw empBonusError.avgAttendance(i.empName)
                        }
                    }else {
                        throw empBonusError.avgCompetency(i.empName)
                    }
                }else {
                    throw empBonusError.inExperienced(i.empName)
                }
            }else {
                throw empBonusError.isPresent(i.empName)
            }
        
    }
    
}

let bonusProgram = BonusProgram()
do {
    let _ = try bonusProgram.allowedForBonus(empEmail: "Vij@tothenew.com")
    let _ = try bonusProgram.allowedForBonus(empEmail: "Abhi@tothenew.com")
    let _ = try bonusProgram.allowedForBonus(empEmail: "Srishti@tothenew.com")
    
}catch empBonusError.isPresent(let name){
    print(name + " is absent")
}catch empBonusError.avgCompetency(let name){
    print(name + " is not a hot competency")
}catch empBonusError.inExperienced(let name){
    print(name + " has not completed a year with us")
}catch empBonusError.avgAttendance(let name){
    print(name + "'s attendance is less than 80")
}
    

