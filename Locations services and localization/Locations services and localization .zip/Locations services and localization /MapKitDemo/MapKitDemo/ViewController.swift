//
//  ViewController.swift
//  MapKitDemo
//
//  Created by TTN on 10/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController , MKAnnotation , CLLocationManagerDelegate{
    
    var coordinate: CLLocationCoordinate2D = CLLocationCoordinate2D(latitude:27.1767 , longitude: 78.0081)
    
    private let locationManager = CLLocationManager()
    
    let jaipurAnnotation = CLLocationCoordinate2D(latitude: 26.9124, longitude: 75.7873)
    
    let mumbaiAnnotation = CLLocationCoordinate2D(latitude: 19.0330, longitude: 73.0297)
    
    let agraAnnotation = CLLocationCoordinate2D(latitude: 27.1767, longitude: 78.0081)
    
    let shimlaAnnotation = CLLocationCoordinate2D(latitude: 31.1048, longitude: 77.1734)
    
    let amritsarAnnotation = CLLocationCoordinate2D(latitude: 31.6340, longitude: 74.8723)
    
    
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        configureLocationServices()
        // Do any additional setup after loading the view.
        
        let annotation1 = MKPointAnnotation()
        annotation1.coordinate = jaipurAnnotation
        annotation1.title = "Jaipur"
        annotation1.subtitle = "This is the first location!"
        mapView.addAnnotation(annotation1)
        
        let annotation2 = MKPointAnnotation()
        annotation2.coordinate = mumbaiAnnotation
        annotation2.title = "Mumbai"
        annotation2.subtitle = "This is the second location!"
        mapView.addAnnotation(annotation2)
        
        let annotation3 = MKPointAnnotation()
        annotation3.coordinate = agraAnnotation
        annotation3.title = "Agra"
        annotation3.subtitle = "This is the third location!"
        mapView.addAnnotation(annotation3)
        
        let annotation4 = MKPointAnnotation()
        annotation4.coordinate = shimlaAnnotation
        annotation4.title = "Shimla"
        annotation4.subtitle = "This is the fourth location!"
        mapView.addAnnotation(annotation4)
        
        let annotation5 = MKPointAnnotation()
        annotation5.coordinate = amritsarAnnotation
        annotation5.title = "Amritsar"
        annotation5.subtitle = "This is the fifth location!"
        mapView.addAnnotation(annotation5)
        
        createPath(jaipurAnnotation: agraAnnotation, dehradunAnnotation: shimlaAnnotation)
        
        self.mapView.delegate = self
        
        let coordinateRegion = MKCoordinateRegion(center: agraAnnotation, latitudinalMeters: 1000, longitudinalMeters: 1000)
        self.mapView.setRegion(coordinateRegion, animated: true)
        
        let circle = MKCircle(center: agraAnnotation, radius: 800)
        self.mapView.addOverlay(circle)
        
        let circle1 = MKCircle(center: shimlaAnnotation, radius: 800)
        self.mapView.addOverlay(circle1)
    }
        
        func createPath(jaipurAnnotation: CLLocationCoordinate2D, dehradunAnnotation: CLLocationCoordinate2D) {
            
            //Route between destinations
            
            let agraPlacemark = MKPlacemark(coordinate: agraAnnotation, addressDictionary: nil)
            
            let shimlaPlacemark = MKPlacemark(coordinate: shimlaAnnotation, addressDictionary: nil)
            
            let agraMapItem = MKMapItem(placemark: agraPlacemark)
            let shimlaMapItem = MKMapItem(placemark: shimlaPlacemark)
            
            let directionRequest = MKDirections.Request()
            directionRequest.source = agraMapItem
            directionRequest.destination = shimlaMapItem
            directionRequest.transportType = .automobile
            
            let direction = MKDirections(request: directionRequest)
            
            direction.calculate{ (response, error) in
                guard let response = response else {
                    if let error = error {
                        print("ERROR FOUND: \(error.localizedDescription)")
                    }
                    return
                }
                
                let route = response.routes[0]
                self.mapView.addOverlay(route.polyline, level: MKOverlayLevel.aboveRoads)
                
                let rect = route.polyline.boundingMapRect
                
                self.mapView.setRegion(MKCoordinateRegion(rect), animated: true)
            }
        }
        
    override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
        }
        
    private func configureLocationServices() {
            locationManager.delegate = self
            
            let status = CLLocationManager.authorizationStatus()
            
            if status == .notDetermined {
                locationManager.requestWhenInUseAuthorization()
            } else if status == .authorizedWhenInUse || status == .authorizedAlways {
                beginLocationUpdates(locationManager: locationManager)
                
            }
        }
        
        private func beginLocationUpdates(locationManager: CLLocationManager) {
            mapView.showsUserLocation = true
            
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }
        
        
        func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
            print(error.localizedDescription)
        }
        
        func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
            print(status)
        }
        
    }

    
    
extension ViewController: MKMapViewDelegate {
        
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard annotation is MKPointAnnotation else { return nil }
        let identifier = "Annotation"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
        if annotationView == nil {
            annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView!.canShowCallout = true
            let btn = UIButton(type: .detailDisclosure)
            annotationView?.rightCalloutAccessoryView = btn
        } else {
            annotationView!.annotation = annotation
        }
        return annotationView
    }
    
    func mapView(_ mapView: MKMapView, didAdd views: [MKAnnotationView]) {
        if let annotation = views.first(where: { $0.reuseIdentifier == "Annotation" })?.annotation {
            mapView.selectAnnotation(annotation, animated: true)
        }
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        
        let vc: SecondViewController = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    internal func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        if overlay.isKind(of: MKPolyline.self) {
            let rendere = MKPolylineRenderer(overlay: overlay)
            rendere.lineWidth = 7
            rendere.strokeColor = .systemBlue
            return rendere
            
        }
        
        if overlay.isKind(of: MKCircle.self){
            let circleRenderer = MKCircleRenderer(overlay: overlay)
            circleRenderer.fillColor = UIColor.systemBlue.withAlphaComponent(0.6)
            circleRenderer.strokeColor = UIColor.red
            circleRenderer.lineWidth = 6
            return circleRenderer
        }
        
        return MKOverlayRenderer(overlay: overlay)
    }
    
}
    

