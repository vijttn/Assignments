//
//  CoreDataManager.swift
//  Final_Project_App
//
//  Created by TTN on 17/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import CoreData

struct  CoreDataManager {
    
    static let shared = CoreDataManager()
    
    let persistentContainer: NSPersistentContainer = {
        
        let container = NSPersistentContainer(name: "Final_Project_App")
        container.loadPersistentStores { (storeDescription, error) in
            if let error = error {
                fatalError("Loading of store failed \(error)")
            }
            
        }
         return container
    }()
   
    func createUserDetails(firstName: String, lastName: String, email: String, password: String, dob: Date) -> UserData? {
        
        let context = persistentContainer.viewContext
        let userdata = NSEntityDescription.insertNewObject(forEntityName: "UserData", into: context) as! UserData
        userdata.firstName = firstName
        userdata.lastName = lastName
        userdata.email = email
        userdata.password = password
        userdata.dob = dob
        
        do {
            try context.save()
            return userdata
        } catch let createError {
            print("failed to create: \(createError)")
        }
        return nil
    }
    
    func fetchUserDetails() -> [UserData]? {
        
        let context = persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<UserData>(entityName: "UserData")
        
        do {
            let details = try context.fetch(fetchRequest)
            return details
        } catch let fetchError {
            print("Failed to fetch: \(fetchError)")
        }
        return nil
    }
    
    
    func fetchUserDetails(withEmail email: String) -> UserData? {
        
        let context = persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<UserData>(entityName: "UserData")
        fetchRequest.fetchLimit = 1
        fetchRequest.predicate = NSPredicate(format: "email == %@", email)
        
        do {
            let details = try context.fetch(fetchRequest)
            return details.first
        } catch let fetchError {
            print("Failed to fetch User details: \(fetchError)")
        }
        return nil
    }
    
    func deleteUserDetails(userdetails: UserData){
        
        let context = persistentContainer.viewContext
        context.delete(userdetails)
        
        do {
            try context.save()
        } catch let saveError {
            print ("Failed to delete: \(saveError)")
        }
        
    }
    
    
}
