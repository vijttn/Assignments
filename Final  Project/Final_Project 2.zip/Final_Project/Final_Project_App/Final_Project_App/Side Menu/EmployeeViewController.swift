//
//  EmployeeViewController.swift
//  Final_Project_App
//
//  Created by TTN on 30/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class EmployeeViewController: UIViewController {

    var backButton: UIBarButtonItem?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
    }
    
    @objc func handleDismiss() {
        dismiss(animated: true, completion: nil)
    }
    
    func configureUI() {
        view.backgroundColor  = .white
        navigationController?.navigationBar.barTintColor = .darkGray
        navigationItem.title = "Employee"
        navigationController?.navigationBar.barStyle = .black
        backButton = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(handleDismiss))
        backButton?.tintColor = .black
        navigationItem.leftBarButtonItem = backButton

    }

}
