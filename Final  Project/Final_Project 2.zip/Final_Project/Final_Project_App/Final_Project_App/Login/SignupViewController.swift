//
//  SignupViewController.swift
//  Final_Project_App
//
//  Created by TTN on 16/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit
import CoreData

class SignupViewController: UIViewController {
    
    
    var userData = [UserData?]()
    @IBOutlet weak var firstNameField: UITextField!
    @IBOutlet weak var lastNameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    @IBOutlet weak var confirmPasswordField: UITextField!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        datePicker.datePickerMode = .date
        datePicker.preferredDatePickerStyle = .wheels
    }
    
    @IBAction func submitButtonTapped(_ sender: Any) {
        
        if let fname = firstNameField.text, let lname = lastNameField.text, let email = emailField.text, let password = passwordField.text, let confirmpassword = confirmPasswordField.text{
            if fname == ""{
                openAlert(title: "Alert", message:  "Please enter first name.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
                    print("okay clicked!")
                    }])
            }else if lname == ""{
                openAlert(title: "Alert", message:  "Please enter last name.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
                    print("okay clicked!")
                    }])
            }else if !email.validateEmailId(){
                openAlert(title: "Alert", message:  "Email address not found.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
                    print("okay clicked!")
                    }])
            }else if !password.validatePassword(){
                openAlert(title: "Alert", message:  "Enter a valid password", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
                    print("okay clicked!")
                    }])
            }else{
                if confirmpassword == ""{
                    openAlert(title: "Alert", message:  "Please confirm password.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
                        print("okay clicked!")
                        }])
                }else {
                    if password == confirmpassword {
                        userData = [CoreDataManager.shared.createUserDetails(firstName: firstNameField!.text ?? "", lastName: lastNameField!.text ?? "", email: emailField!.text ?? "", password: passwordField!.text ?? "", dob: datePicker!.date)]
                        
                        navigationController?.popToRootViewController(animated: true)
                    }else {
                        openAlert(title: "Alert", message:  "Password does not match.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
                            print("okay clicked!")
                            }])
                    }
                }
                
            }
            
        }else {
            openAlert(title: "Alert", message:  "Please check your details.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
                print("okay clicked!")
                }])
        }
        
    }
}
