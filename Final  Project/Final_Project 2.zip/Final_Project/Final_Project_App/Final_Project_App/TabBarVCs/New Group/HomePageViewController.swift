//
//  HomePageViewController.swift
//  Final_Project_App
//
//  Created by TTN on 18/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit
import SideMenu

class HomePageViewController: UIViewController, MenuControllerDelegate {
    
    
    @IBOutlet weak var homePageTableView: UITableView!
    let homeVM = HomeViewModel()
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(fetchHomeScreenData), for: UIControl.Event.valueChanged)
        refreshControl.tintColor = UIColor.red
        
        return refreshControl
    }()
    
    private var sideMenu: SideMenuNavigationController?
    private let employeeController = EmployeeViewController()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        homePageTableView.addSubview(self.refreshControl)
        homePageTableView.register(CustomTableViewCell.nib(), forCellReuseIdentifier: CustomTableViewCell.identifier)
        homePageTableView.register(BannerTableViewCell.nib(), forCellReuseIdentifier: BannerTableViewCell.identifier)
        homePageTableView.delegate = self
        homePageTableView.dataSource = self
        homePageTableView.estimatedRowHeight = UITableView.automaticDimension
        homePageTableView.rowHeight = UITableView.automaticDimension
        fetchHomeScreenData()
        
        let menu = MenuController(with: SideMenuItem.allCases)
        
        menu.delegate = self
        
        sideMenu = SideMenuNavigationController(rootViewController: menu)
        sideMenu?.leftSide = true
        sideMenu?.setNavigationBarHidden(true, animated: false)
        
        SideMenuManager.default.leftMenuNavigationController = sideMenu
        SideMenuManager.default.addPanGestureToPresent(toView: view)
        
        addChildControllers()
    }
    
    
    
    @objc func fetchHomeScreenData(){
        homeVM.fetchHomeApiData { (success, message) in
            self.refreshControl.endRefreshing()
            if success {
                self.homePageTableView.reloadData()
            } else {
                print(message)
            }
        }
    }
    
    private func addChildControllers() {
        addChild(employeeController)
        
        
        view.addSubview(employeeController.view)
        
        
        employeeController.view.frame = view.bounds
        
        
        employeeController.didMove(toParent: self)
        
        
        employeeController.view.isHidden = true
        
    }
    
    @IBAction func didTapMenuButton(){
        present(sideMenu!, animated: true)
    }
    
    func didSelectMenuItem(menuOption: SideMenuItem) {
        sideMenu?.dismiss(animated: true, completion: nil)
        
        //        title = named.rawValue
        switch menuOption {
        case .home:
            employeeController.view.isHidden = true
        case .location:
            employeeController.view.isHidden = true
            openAlert(title: "Alert", message:  "Movies Tapped.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
            print("okay clicked!")
            }])
        case .movies:
            employeeController.view.isHidden = true
            openAlert(title: "Alert", message:  "Location Tapped.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
            print("okay clicked!")
            }])
        case .notification:
            employeeController.view.isHidden = true
            openAlert(title: "Alert", message:  "Notification Tapped.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
            print("okay clicked!")
            }])
        case .employee:
            let controller = EmployeeViewController()
            present(UINavigationController(rootViewController: controller) , animated: true, completion: nil)
        case .country:
            employeeController.view.isHidden = true
            openAlert(title: "Alert", message:  "Country Tapped.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
            print("okay clicked!")
            }])
        case .language:
            employeeController.view.isHidden = true
            openAlert(title: "Alert", message:  "Language Tapped.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
            print("okay clicked!")
            }])
        case .aboutus:
            employeeController.view.isHidden = true
            openAlert(title: "Alert", message:  "About Us Tapped.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
            print("okay clicked!")
            }])
        case .faq:
            employeeController.view.isHidden = true
            openAlert(title: "Alert", message:  "FAQ Tapped.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
            print("okay clicked!")
            }])
        case .changetheme:
            employeeController.view.isHidden = true
            openAlert(title: "Alert", message:  "Theme Tapped.", alertStyle: .alert, actionTitles: ["okay"], actionStyles: [.default], actions: [{ _ in
            print("okay clicked!")
            }])
        case .logout:
            employeeController.view.isHidden = true
            UserDefaults.standard.set(false, forKey: "ISUSERLOGGEDIN")
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let loginNavController = storyboard.instantiateViewController(identifier: "LoginNavigationController")
            
            (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(loginNavController)
        }
        
    }
    
}


extension HomePageViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        homeVM.homeApiData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = homePageTableView.dequeueReusableCell(withIdentifier: BannerTableViewCell.identifier, for: indexPath) as! BannerTableViewCell
            cell.configure(homeVM.homeApiData[indexPath.row])
            return cell
        } else {
            let cell = homePageTableView.dequeueReusableCell(withIdentifier: CustomTableViewCell.identifier, for: indexPath) as! CustomTableViewCell
            cell.configure(homeVM.homeApiData[indexPath.row])
            return cell
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return homePageTableView.frame.width * (9/16)
        } else {
            return UITableView.automaticDimension
        }
    }
    
    //    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    ////        let cell = homePageTableView.cellForRow(at: indexPath) as! CustomTableViewCell
    ////        cell.buttonAction()
    //        homePageTableView.reloadRows(at: [indexPath], with: .middle)
    //
    //    }
    
}
