//
//  FavoriteViewController.swift
//  Final_Project_App
//
//  Created by TTN on 25/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class FavoriteViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
