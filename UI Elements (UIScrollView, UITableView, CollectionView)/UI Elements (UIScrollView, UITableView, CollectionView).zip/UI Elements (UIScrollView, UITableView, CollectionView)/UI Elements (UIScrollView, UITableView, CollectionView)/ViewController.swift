//
//  ViewController.swift
//  UI Elements (UIScrollView, UITableView, CollectionView)
//
//  Created by TTN on 19/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var table : UITableView!
    
    var models = [Model]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        models.append(Model(text: "DOG 1", imageName: "dog"))
        models.append(Model(text: "DOG 2", imageName: "dog1"))
        models.append(Model(text: "DOG 3", imageName: "dog3"))
        models.append(Model(text: "SMILEYS", imageName: "smiley"))
        
        table.register(CustomTableCellTableViewCell.nib(), forCellReuseIdentifier: CustomTableCellTableViewCell.identifier)
        table.delegate = self
        table.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return models.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: CustomTableCellTableViewCell.identifier, for: indexPath) as! CustomTableCellTableViewCell
        cell.configure(with: models)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180.0
    }

}

struct Model{
    let text : String
    let imageName : String
    
    init(text:String,imageName:String) {
        self.text = text
        self.imageName = imageName
    }
    
}


