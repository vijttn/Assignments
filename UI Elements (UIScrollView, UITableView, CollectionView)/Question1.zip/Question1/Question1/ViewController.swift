//
//  ViewController.swift
//  Question1
//
//  Created by TTN on 06/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

struct Person {

    var name: String
    var address: String
    var age: String
    var hobby: String

    init(name: String, address: String, age: String, hobby: String){

        self.name = name
        self.address = address
        self.age = age
        self.hobby = hobby
    }
}

class ViewController: UIViewController {

  
    @IBOutlet weak var nameField: UITextField!
    
    @IBOutlet weak var addressField: UITextField!
    
    @IBOutlet weak var ageField: UITextField!
    
    @IBOutlet weak var hobbyField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    var objOfPerson: [Person] =  []
    var detailsOfPerson: Person?
  
    @IBAction func submitButtonTapped(_ sender: Any) {
        
        
        detailsOfPerson = Person(name: nameField!.text ?? "", address: addressField!.text ?? "", age: ageField!.text ?? "", hobby: hobbyField!.text ?? "")
        
        objOfPerson.append(detailsOfPerson!)
        
    }
    @IBAction func showButtonTapped(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(identifier: "Second") as! SecondViewController
            vc.recievedData = objOfPerson
        navigationController?.pushViewController(vc, animated: true)
    }
}


