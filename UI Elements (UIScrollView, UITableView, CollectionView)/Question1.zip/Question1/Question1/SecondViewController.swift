//
//  SecondViewController.swift
//  Question1
//
//  Created by TTN on 06/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
   
    
    @IBOutlet weak var myTableView: UITableView!
        
    
     var recievedData: [Person] = []
   

    
    override func viewDidLoad() {
        super.viewDidLoad()

     
         myTableView.register(CustomTableViewCell.nib(), forCellReuseIdentifier: CustomTableViewCell.identifier)
       
        // Do any additional setup after loading the view.
        
        myTableView.delegate = self
        myTableView.dataSource = self
         myTableView.reloadData()
    }
    

   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return recievedData.count
      }
      
      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let cell = myTableView.dequeueReusableCell(withIdentifier: CustomTableViewCell.identifier, for: indexPath) as! CustomTableViewCell

          cell.configureMyFunction(element: recievedData[indexPath.row])
              return cell
      }

}
