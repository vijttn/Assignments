//
//  ViewController.swift
//  CocoapodsAF
//
//  Created by TTN on 23/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit
import Alamofire
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        AF.request("https://jsonplaceholder.typicode.com/users").response { (response) in
            debugPrint(response)
        }
    }


}

