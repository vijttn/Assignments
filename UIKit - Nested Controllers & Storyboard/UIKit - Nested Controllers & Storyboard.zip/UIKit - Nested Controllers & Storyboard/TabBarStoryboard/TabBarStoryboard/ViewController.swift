//
//  ViewController.swift
//  TabBarStoryboard
//
//  Created by TTN on 15/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        displayLbl.text = "Favorite"
    }


}

