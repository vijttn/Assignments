//
//  ViewController.swift
//  abc
//
//  Created by Shivam Srivastava on 04/03/19.
//  Copyright © 2019 Shivam Srivastava. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var view2 : UIView!
    @IBOutlet weak var lbl : UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lbl.text = "This is sample text."
        view2.layer.cornerRadius = 15.0
        view2.layer.shadowColor = UIColor.init(white: 220.0/255.0, alpha: 2.0).cgColor
        view2.layer.shadowOpacity = 1.0
        view2.layer.shadowRadius = 5.0
        view2.layer.shadowOffset = CGSize(width: -10, height: 10)
        
    }



}

